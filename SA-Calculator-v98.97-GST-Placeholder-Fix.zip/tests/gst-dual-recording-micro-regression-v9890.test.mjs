import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const read=f=>fs.readFileSync(path.join(root,f),'utf8');
const css=read('assets/css/tool-reference-ui.css');
const js=read('assets/js/app.js');
const html=read('index.html');
const pkg=JSON.parse(read('package.json'));
test('dual recordings: amount and GST rate cards use matching compact geometry',()=>{
 const block=css.slice(css.lastIndexOf('v98.91 — authoritative GST layout'));
 assert.match(block,/\.gst-reference-card[\s\S]*height:98px/);
 assert.match(block,/\.gst-rate-card[\s\S]*grid-template-columns:55px minmax\(0,1fr\)/);
 assert.match(block,/\.gst-amount-field[\s\S]*grid-template-columns:55px minmax\(0,1fr\)/);
});
test('quick rates share the Add rate input row and remain inside its field',()=>{
 const block=css.slice(css.lastIndexOf('v98.91 — authoritative GST layout'));
 assert.match(html,/<div class="gst-rate-entry-row">[\s\S]*?class="reference-input-suffix"[\s\S]*?class="gst-quick-rates"/);
 assert.match(block,/\.gst-rate-entry-row[\s\S]*display:flex/);
 assert.match(block,/\.gst-quick-rates[\s\S]*flex:0 0 auto/);
});
test('placeholder has one explicit empty state and cannot overlay entered digits',()=>{
 assert.match(js,/target\.classList\.toggle\('is-empty', isEmpty\)/);
 const block=css.slice(css.lastIndexOf('v98.91 — authoritative GST layout'));
 assert.match(block,/#tax-orig\.is-empty::after/);
 assert.match(block,/#tax-rate\.is-empty::after/);
 assert.match(block,/#tax-orig::before[\s\S]*content:none/);
});
test('only the active GST input displays one caret; long values scroll horizontally',()=>{
 const block=css.slice(css.lastIndexOf('v98.91 — authoritative GST layout'));
 assert.match(block,/#tax-orig:not\(\.active\).*input-cursor/);
 assert.match(block,/overflow-x:auto/);
 assert.match(block,/user-select:none/);
 assert.match(js,/target\.scrollLeft = Math\.max/);
});
test('GST result card stays light and does not clip its result rows',()=>{
 const block=css.slice(css.lastIndexOf('v98.91 — authoritative GST layout'));
 assert.match(block,/\.gst-result-card[\s\S]*background:#fff !important/);
 assert.match(block,/overflow:visible !important/);
});
test('v98.91 release identity and cache agree',()=>{
 assert.equal(pkg.version,'1.99.11-v98.97'); assert.equal(pkg.androidVersionCode,1099117);
 assert.match(read('service-worker.js'),/sa-calculator-v98-97-gst-placeholder-field-contract-v9897/);
 assert.match(js,/1\.99\.11-v98\.97/);
});
