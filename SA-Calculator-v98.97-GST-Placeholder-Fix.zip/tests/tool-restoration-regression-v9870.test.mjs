import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve('.');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const js=fs.readFileSync(path.join(root,'assets/js/app.js'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/app.css'),'utf8');
const loc=fs.readFileSync(path.join(root,'assets/js/localization.js'),'utf8');
const required=['salestax','loan','savings','salary','tip','sip','currencies','discount','percent','units','agecalc','bodymetrics'];
test('all 12 reference tools are registered and their screens are present',()=>{
  for(const id of required){
    assert.ok(html.includes(`id="screen-${id}"`),`${id} screen missing from HTML`);
    assert.ok(js.toLowerCase().includes(id),`${id} missing from JS`);
  }
});
test('reference UI retains shared numeric keypad, card and unit/date controls',()=>{
  for(const token of ['keypad','keypad-grid','reference-field','tool-screen','loan','bmi','agecalc','units']) {
    assert.ok((html+'\\n'+js+'\\n'+css).toLowerCase().includes(token),`${token} missing`);
  }
});
test('root and Android web assets are byte-identical',()=>{
  for(const rel of ['index.html','assets/js/app.js','assets/js/localization.js','assets/css/app.css','assets/css/tool-reference-ui.css']){
    assert.deepEqual(fs.readFileSync(path.join(root,rel)),fs.readFileSync(path.join(root,'www',rel)),`${rel} mismatch`);
  }
});
test('localization bundles and currency catalog remain available',()=>{
  assert.ok(loc.length>100000);
  assert.match(js,/currency/i);
});
