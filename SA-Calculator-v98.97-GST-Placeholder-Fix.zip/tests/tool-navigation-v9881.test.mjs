import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const js=fs.readFileSync('assets/js/app.js','utf8');
const css=fs.readFileSync('assets/css/tool-reference-ui.css','utf8');
const html=fs.readFileSync('index.html','utf8');

test('v98.81 tool navigation returns to the exact parent surface',()=>{
  assert.match(js,/STATE\.previousScreen \|\| 'calc'/);
  assert.match(js,/Tool screens must return to the surface they were opened from/);
});

test('v98.81 result lifecycle requires explicit calculate/equals for BMI and Age',()=>{
  assert.match(css,/screen-bodymetrics\[data-tool-calculated="false"\] \.body-metric-result/);
  assert.match(css,/screen-agecalc\[data-tool-calculated="false"\] \.reference-result-card/);
  assert.match(js,/age\.dataset\.toolCalculated = 'false'/);
});

test('v98.81 tool screens retain the shared docked keypad and native reference controls',()=>{
  for (const id of ['salestax','loan','currencies','discount','units','agecalc','bodymetrics']) assert.ok(html.includes(`id="screen-${id}"`));
  assert.match(js,/data-tool-key="EQUAL"/);
});
