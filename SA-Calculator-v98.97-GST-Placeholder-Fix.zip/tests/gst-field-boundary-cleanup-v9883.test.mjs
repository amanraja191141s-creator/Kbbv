import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const html = fs.readFileSync('index.html', 'utf8');
const css = fs.readFileSync('assets/css/tool-reference-ui.css', 'utf8');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const workflow = fs.readFileSync('.github/workflows/main.yml', 'utf8');

test('GST amount and rate entry surfaces have no decorative boundary or inset box', () => {
  assert.match(css, /#screen-viewport #screen-salestax \.gst-amount-field[\s\S]*?border:0 !important/);
  assert.match(css, /#screen-viewport #screen-salestax \.gst-rate-field[\s\S]*?border:0 !important/);
  assert.match(css, /#screen-viewport #screen-salestax #tax-orig \.input-text[\s\S]*?text-align:left !important/);
  assert.match(css, /#screen-viewport #screen-salestax #tax-rate \.input-text[\s\S]*?text-align:left !important/);
});

test('GST duplicate mode select is hidden while accessible segmented controls remain', () => {
  assert.match(html, /data-gst-mode="exclusive"/);
  assert.match(html, /data-gst-mode="inclusive"/);
  assert.match(css, /#screen-viewport #screen-salestax #tax-mode[\s\S]*?display:none !important/);
});

test('GST quick-rate pills and mode/place controls do not render extra outlines', () => {
  assert.match(css, /\.gst-quick-rates button \{[\s\S]*?border:0 !important/);
  assert.match(css, /\.gst-choice-row \.gst-choice \{[\s\S]*?border:0 !important/);
  assert.match(css, /grid-template-columns:repeat\(2,minmax\(0,1fr\)\)/);
});

test('v98.85 release identity is consistent in package and Android workflow', () => {
  assert.equal(pkg.version, '1.99.11-v98.97');
  assert.equal(pkg.androidVersionCode, 1099117);
  assert.match(workflow, /1\.99\.11-v98\.97/);
  assert.match(workflow, /1099117/);
  assert.match(workflow, /gst-field-boundary-cleanup-v9883\.test\.mjs/);
});
