# SA Calculator v98.87 — GST Screenshot Geometry

- Calibrated GST amount/rate card geometry to the supplied 709 × 1536 screenshot.
- Matched icon tile size, text start positions, mode/state button widths, quick-rate positions and keypad geometry using responsive CSS equivalents.
- Preserved single inline caret and left-aligned entry behavior.
- Kept result panel auto-height and accessible by scrolling.
- Added four pixel-geometry regression tests and updated release identity/workflow checks.
- Release version: `1.99.01-v98.87`; Android versionCode: `1099107`.
