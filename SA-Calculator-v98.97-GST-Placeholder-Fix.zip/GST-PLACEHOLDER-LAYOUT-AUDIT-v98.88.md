# SA Calculator v98.88 — GST placeholder and layout regression audit

## Evidence reviewed
- `Screenshot_20261124_131059.jpg`: 709 × 1536 px, malformed GST form.
- `Screenshot_20261124_131153.jpg`: 709 × 1536 px, intended reference layout.
- Source baseline: `SA-Calculator-v98.87-GST-Pixel-Geometry.zip`.

## Confirmed defects in the malformed screenshot
1. **Original Amount placeholder disappears when the inline caret is inserted.** The previous CSS used `:empty` pseudo selectors. Once the caret becomes a child of `.input-text`, that element is no longer `:empty`, so `Enter amount` is suppressed.
2. **GST Rate placeholder is duplicated.** Both the outer `.input-val-box[data-placeholder]::before` and inner `.input-text:empty::before` can render the same placeholder.
3. **GST Rate field is structurally unstable.** Earlier CSS changes `.gst-rate-field` to `display:contents`, then places its pseudo icon, label and nested suffix as separate grid items. Competing historical grid declarations cause the label/input to drop below the icon and create an oversized card.
4. **Quick-rate pills fall to the bottom of the oversized card.** Their placement is coupled to the unstable parent grid rather than a stable two-column card layout.
5. **Card height expands from the intended compact reference geometry.** In screenshot 1 the GST rate card is about 308 screenshot pixels tall; screenshot 2 shows the intended card around 177 screenshot pixels tall.
6. **Amount card vertical placement/placeholder state differs from the reference.** The label and caret remain, but the placeholder is absent, leaving a large blank input area.

## Intended geometry from reference screenshot 2
Coordinates are approximate screenshot pixels from the 709 × 1536 canvas (±3 px):
- Amount card: x≈25, y≈182, w≈660, h≈177.
- Amount icon tile: x≈53, y≈221, w≈98, h≈98.
- Amount label: x≈171, y≈222.
- Amount placeholder: x≈171, y≈273.
- Mode buttons: y≈380, h≈50; right aligned.
- GST rate card: x≈25, y≈450, w≈660, h≈177.
- Rate icon tile: x≈53, y≈488, w≈98, h≈98.
- Rate label: x≈171, y≈489.
- Rate placeholder: x≈171, y≈540.
- 5% pill: x≈459, y≈513, w≈89, h≈50.
- 18% pill: x≈558, y≈513, w≈98, h≈50.
- State controls: y≈647, h≈49; right aligned.
- Keypad begins around y≈808.

These are screenshot pixels, not Android dp. The implementation uses responsive CSS dimensions and grid constraints rather than hardcoding the 709px screenshot width.

## Implemented correction
- Replaced the accumulated conflicting GST rules with a final authoritative v98.88 layout block.
- Amount field uses a stable 2-column grid: icon in column 1; label and input in column 2.
- Rate card uses a stable outer grid: rate field on the left, quick-rate buttons on the right. The rate field itself uses a stable 2-column grid.
- Removed the `display:contents` dependency for the rate field.
- Disabled the duplicate outer-box placeholder pseudo-element.
- Placeholder now renders once from the inner text span when it contains only the inline caret. The caret remains before the placeholder, preserving the expected start position.
- Mode and state controls remain separate normal-flow rows.
- Kept calculation logic, quick-rate event handlers, state selection and keypad behavior unchanged.
- Added responsive rules for narrow and short viewports.

## Regression coverage
New tests verify one placeholder source per field, explicit rate-field grid layout, normal-flow controls, result-card sizing, release identity and cache namespace. Full release suite result: **128/128 passed**.

## Verification boundary
Source-level and automated regression checks passed. A rendered Android WebView screenshot, physical touch test, rotation test, remote GitHub Actions run and APK build were not performed in this environment. Those checks remain necessary before claiming device-level perfection or lag-free performance.
