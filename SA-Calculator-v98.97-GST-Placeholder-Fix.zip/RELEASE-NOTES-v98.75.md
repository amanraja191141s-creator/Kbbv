# SA Calculator v98.75 — Tools UI / Navigation Hardening

## Reference-video pass
- Fixed tool back navigation so a tool opened from Tools/Favorites returns to the exact parent surface instead of always returning to Calculator.
- Preserved shared keypad lifecycle: navigation dismisses the keypad before route changes; editing a field clears stale committed results.
- Result cards for BMI and Age now respect the explicit Calculate/equals lifecycle instead of appearing prematurely during data entry.
- Age input changes immediately invalidate the previous result until Calculate/equals is invoked again.
- Added Android WebView touch-action/tap-highlight hardening for tool toolbar and bottom navigation controls.
- Kept Currency/Unit converters live because their reference flow is conversion-as-you-type.
- Root and `www/` web assets synchronized.
- Release identity synchronized to `1.98.90-v98.76`, Android version code `1098601`.

## Validation
- Node release regression suite is included in the ZIP.
- Source and `www/` assets are synchronized after patching.

## CI hotfix
- Fixed the v98.75 release bundle corruption where the tool-hardening suffix was serialized with literal `\n` characters.
- Re-synchronized `assets/js/app.js` and `www/assets/js/app.js`, plus the tool reference CSS bundle.
- Added a pre-dependency JavaScript syntax gate so malformed release source fails immediately with a clear diagnostic.
- Added a regression test preventing recurrence of the literal escaped-newline suffix.
## Action-time reference-video hardening
- Fixed shared tool keypad runtime crash caused by an out-of-scope `screenId` reference.
- Unit Converter now opens directly on the reference workspace with horizontal category chips.
- Currency/Unit picker headings and search behavior now match the supplied reference flows.
- Currency defaults to USD → INR with a clean source input.
- GST and Discount result cards now use the supplied reference-video result structure.
- Age Calculator now renders Current Age + Next Birthday sections after Calculate.
- BMI Calculator now renders the reference BMI summary/table and enforces the three-digit entry limit.
- Android/Capacitor Back handling now closes the keypad first and then returns to the exact parent tool surface.
- Added action-time regression coverage to the release test command.
